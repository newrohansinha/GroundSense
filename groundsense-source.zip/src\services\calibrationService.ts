import { supabase } from "../lib/supabase";

export type CompanyCalibrationInput = {
  annual_revenue?: number | null;
  gross_margin_pct?: number | null;
  cogs?: number | null;

  manufacturing_revenue?: number | null;
  construction_revenue?: number | null;
  utilities_revenue?: number | null;
  industrial_maintenance_revenue?: number | null;

  steel_spend?: number | null;
  copper_spend?: number | null;
  aluminum_spend?: number | null;
  freight_spend?: number | null;

  pass_through_coverage_pct?: number | null;
  average_repricing_lag_days?: number | null;

  quote_win_rate_pct?: number | null;
  lost_quote_rate_pct?: number | null;
  customer_churn_rate_pct?: number | null;

  backorder_rate_pct?: number | null;
  backorder_cancellation_rate_pct?: number | null;

  expedite_premium_pct?: number | null;
  average_supplier_lead_time_days?: number | null;

  inventory_days?: number | null;
  fill_rate_pct?: number | null;

  notes?: string | null;
};

export async function getCalibrationForCompany(companyId: string) {
  const { data, error } = await supabase
    .from("company_calibration")
    .select("*")
    .eq("company_id", companyId)
    .maybeSingle();

  if (error) {
    throw error;
  }

  return data;
}

export async function saveCalibrationForCompany(
  companyId: string,
  input: CompanyCalibrationInput
) {
  const payload = {
    company_id: companyId,
    annual_revenue: input.annual_revenue ?? null,
    gross_margin_pct: input.gross_margin_pct ?? null,
    cogs: input.cogs ?? null,

    manufacturing_revenue: input.manufacturing_revenue ?? null,
    construction_revenue: input.construction_revenue ?? null,
    utilities_revenue: input.utilities_revenue ?? null,
    industrial_maintenance_revenue:
      input.industrial_maintenance_revenue ?? null,

    steel_spend: input.steel_spend ?? null,
    copper_spend: input.copper_spend ?? null,
    aluminum_spend: input.aluminum_spend ?? null,
    freight_spend: input.freight_spend ?? null,

    pass_through_coverage_pct: input.pass_through_coverage_pct ?? null,
    average_repricing_lag_days: input.average_repricing_lag_days ?? null,

    quote_win_rate_pct: input.quote_win_rate_pct ?? null,
    lost_quote_rate_pct: input.lost_quote_rate_pct ?? null,
    customer_churn_rate_pct: input.customer_churn_rate_pct ?? null,

    backorder_rate_pct: input.backorder_rate_pct ?? null,
    backorder_cancellation_rate_pct:
      input.backorder_cancellation_rate_pct ?? null,

    expedite_premium_pct: input.expedite_premium_pct ?? null,
    average_supplier_lead_time_days:
      input.average_supplier_lead_time_days ?? null,

    inventory_days: input.inventory_days ?? null,
    fill_rate_pct: input.fill_rate_pct ?? null,

    notes: input.notes ?? null,
    updated_at: new Date().toISOString(),
  };

  const { data, error } = await supabase
    .from("company_calibration")
    .upsert(payload, {
      onConflict: "company_id",
    })
    .select()
    .single();

  if (error) {
    throw error;
  }

  return data;
}