const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

function jsonResponse(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      ...corsHeaders,
      "Content-Type": "application/json",
    },
  });
}

function cleanText(value: unknown, max = 3000) {
  return String(value || "")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, max);
}

function safeArray(value: unknown): any[] {
  return Array.isArray(value) ? value : [];
}


function norm(value: unknown) {
  return String(value || "")
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function includesAny(text: string, terms: string[]) {
  return terms.some((term) => text.includes(term));
}

function uniqueNumbers(values: number[]) {
  return [...new Set(values.filter((value) => Number.isFinite(value) && value > 0))];
}

function articleText(item: any) {
  return norm(
    [
      item.title,
      item.source_name,
      item.query_text,
      item.why_it_matters,
      item.impact_type,
      ...(Array.isArray(item.affected_areas) ? item.affected_areas : []),
    ].join(" ")
  );
}

function isGenericMarketNoise(text: string) {
  return includesAny(text, [
    "scotch whisky",
    "whisky",
    "watch exports",
    "swiss watch",
    "ftse 100",
    "stock gains",
    "market cap",
    "shares",
    "analyst rating",
    "company profile",
    "etf",
    "zacks",
    "motley fool",
    "insider monkey",
    "simply wall st",
    "norges bank",
    "options now available",
    "relative strength",
    "stock watch",
  ]);
}

function evidenceSupportsCluster(cluster: any, item: any) {
  const text = articleText(item);
  const riskType = norm(cluster.risk_type);
  const title = norm(cluster.risk_title);

  const isTariffRisk =
    riskType.includes("tariff") ||
    riskType.includes("trade") ||
    title.includes("tariff") ||
    title.includes("tariffs") ||
    title.includes("duty") ||
    title.includes("duties");

  const isMetalsRisk =
    title.includes("steel") ||
    title.includes("aluminum") ||
    title.includes("aluminium") ||
    title.includes("copper") ||
    title.includes("metals") ||
    riskType.includes("commodity");

  const tariffTerms = [
    "tariff",
    "tariffs",
    "duty",
    "duties",
    "import",
    "imports",
    "section 232",
    "proclamation",
    "white house",
    "trade policy",
  ];

  const directMetalTerms = [
    "steel",
    "aluminum",
    "aluminium",
    "copper",
  ];

  const broadMetalTerms = [
    "metals",
    "base metals",
  ];

  const freightTerms = [
    "freight",
    "container",
    "shipping",
    "logistics",
    "port",
    "vessel",
    "ocean",
    "air freight",
    "transportation",
    "capacity",
    "lead time",
  ];

  const demandTerms = [
    "manufacturing",
    "industrial demand",
    "pmi",
    "construction",
    "orders",
    "customer demand",
    "sales outlook",
    "capex",
    "inventory",
    "destocking",
    "restocking",
  ];

  const competitorTerms = [
    "grainger",
    "msc industrial",
    "applied industrial",
    "competitor",
    "market share",
    "pricing pressure",
    "quote",
    "churn",
  ];

  // Hard reject obvious noise first.
  if (isGenericMarketNoise(text)) {
    return false;
  }

  // For metals tariff risks, require BOTH tariff-policy language AND the exact target commodities.
  // This blocks whisky, watches, generic trade articles, and iron-ore-only articles.
  if (isTariffRisk && isMetalsRisk) {
    const hasTariffPolicy = includesAny(text, tariffTerms);
    const hasDirectTargetMetal = includesAny(text, directMetalTerms);
    const hasOnlyBroadMetal = includesAny(text, broadMetalTerms) && !hasDirectTargetMetal;

    return hasTariffPolicy && hasDirectTargetMetal && !hasOnlyBroadMetal;
  }

  // Commodity-cost risks without tariff framing still need exact commodity relevance.
  if (
    riskType.includes("commodity") ||
    title.includes("steel") ||
    title.includes("aluminum") ||
    title.includes("aluminium") ||
    title.includes("copper")
  ) {
    return includesAny(text, directMetalTerms);
  }

  if (
    riskType.includes("freight") ||
    riskType.includes("logistics") ||
    riskType.includes("supplier") ||
    title.includes("freight") ||
    title.includes("shipping")
  ) {
    return includesAny(text, freightTerms);
  }

  if (
    riskType.includes("demand") ||
    riskType.includes("macro") ||
    title.includes("demand")
  ) {
    return includesAny(text, demandTerms);
  }

  if (
    riskType.includes("competitor") ||
    title.includes("competitor") ||
    title.includes("competitive")
  ) {
    return includesAny(text, competitorTerms);
  }

  return true;
}

function getCleanEvidenceIndexes(cluster: any, evidence: any[]) {
  const rawIndexes = uniqueNumbers(
    safeArray(cluster.evidence_indexes)
      .map((value) => Number(value))
      .filter((value) => value >= 1 && value <= evidence.length)
  );

  const cleanIndexes = rawIndexes.filter((index) =>
    evidenceSupportsCluster(cluster, evidence[index - 1])
  );

  // Allow a risk with 2 very direct articles rather than padding it with weak articles.
  return cleanIndexes.slice(0, 8);
}
function clampNumber(value: unknown, min: number, max: number, fallback: number) {
  const n = Number(value);

  if (!Number.isFinite(n)) return fallback;

  return Math.max(min, Math.min(max, n));
}

function parseJsonFromGemini(text: string) {
  const raw = String(text || "").trim();

  const cleaned = raw
    .replace(/^```json/i, "")
    .replace(/^```/i, "")
    .replace(/```$/i, "")
    .trim();

  try {
    return JSON.parse(cleaned);
  } catch {
    const objectMatch = cleaned.match(/\{[\s\S]*\}/);

    if (objectMatch) {
      try {
        return JSON.parse(objectMatch[0]);
      } catch {
        // fall through
      }
    }

    throw new Error(
      `Gemini response did not contain valid JSON. Raw response: ${cleaned.slice(
        0,
        1500
      )}`
    );
  }
}

async function callGemini(prompt: string) {
  const apiKey = Deno.env.get("GEMINI_API_KEY");

  if (!apiKey) {
    throw new Error("Missing GEMINI_API_KEY secret.");
  }

  const model = Deno.env.get("GEMINI_MODEL") || "gemini-2.5-flash-lite";

  async function generate(textPrompt: string) {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          generationConfig: {
            temperature: 0.05,
            topP: 0.8,
            maxOutputTokens: 12000,
            responseMimeType: "application/json",
          },
          contents: [
            {
              role: "user",
              parts: [{ text: textPrompt }],
            },
          ],
        }),
      }
    );

    if (!response.ok) {
      const errorText = await response.text();

      throw new Error(
        `Gemini error ${response.status}: ${errorText.slice(0, 1200)}`
      );
    }

    const data = await response.json();

    const text =
      data?.candidates?.[0]?.content?.parts
        ?.map((part: any) => part.text || "")
        .join("\n") || "";

    return text;
  }

  const firstText = await generate(prompt);

  try {
    return parseJsonFromGemini(firstText);
  } catch {
    const repairPrompt = `
You returned invalid or truncated JSON.

Repair the following text into valid compact JSON.
Return ONLY valid JSON.
Do not add markdown.
Do not add explanation.

Required top-level schema:
{
  "risk_clusters": []
}

Broken JSON:
${firstText.slice(0, 9000)}
`;

    const repairedText = await generate(repairPrompt);

    return parseJsonFromGemini(repairedText);
  }
}

function formatMoneyForPath(value: number) {
  if (value >= 1_000_000_000) {
    return `$${(value / 1_000_000_000).toFixed(1)}B`;
  }

  if (value >= 1_000_000) {
    return `$${(value / 1_000_000).toFixed(1)}M`;
  }

  if (value >= 1_000) {
    return `$${(value / 1_000).toFixed(0)}K`;
  }

  return `$${value.toFixed(0)}`;
}

function evidenceMultiplier(count: number) {
  return Math.min(1.18, 1 + Math.log10(count + 1) * 0.08);
}

function qualityMultiplier(score: number) {
  return Math.max(0.75, Math.min(1.15, score / 80));
}

function getBaseExposureForRisk(input: {
  riskType: string;
  company: any;
}) {
  const riskType = String(input.riskType || "").toLowerCase();
  const revenueRange = String(input.company?.revenue_range || "").toLowerCase();

  let annualRevenue = 7_500_000_000;

  if (revenueRange.includes("1b")) annualRevenue = 1_500_000_000;
  if (revenueRange.includes("2b")) annualRevenue = 2_500_000_000;
  if (revenueRange.includes("3b")) annualRevenue = 3_500_000_000;
  if (revenueRange.includes("4b")) annualRevenue = 4_500_000_000;
  if (revenueRange.includes("5b")) annualRevenue = 5_500_000_000;
  if (revenueRange.includes("6b")) annualRevenue = 6_500_000_000;
  if (revenueRange.includes("7b") || revenueRange.includes("8b")) {
    annualRevenue = 7_500_000_000;
  }

  if (
    riskType.includes("commodity") ||
    riskType.includes("tariff") ||
    riskType.includes("trade") ||
    riskType.includes("metals")
  ) {
    return {
      base_exposure_type: "estimated_input_cost_exposure",
      base_exposure_value: 150_000_000,
      low_rate: 0.012,
      high_rate: 0.035,
    };
  }

  if (
    riskType.includes("freight") ||
    riskType.includes("logistics") ||
    riskType.includes("supplier") ||
    riskType.includes("shipping")
  ) {
    return {
      base_exposure_type: "estimated_cogs_exposure",
      base_exposure_value: annualRevenue * 0.55,
      low_rate: 0.0012,
      high_rate: 0.004,
    };
  }

  if (
    riskType.includes("demand") ||
    riskType.includes("macro") ||
    riskType.includes("market")
  ) {
    return {
      base_exposure_type: "estimated_segment_revenue_exposure",
      base_exposure_value: annualRevenue * 0.75,
      low_rate: 0.001,
      high_rate: 0.004,
    };
  }

  if (riskType.includes("competitor")) {
    return {
      base_exposure_type: "estimated_competitive_revenue_exposure",
      base_exposure_value: annualRevenue * 0.45,
      low_rate: 0.001,
      high_rate: 0.0035,
    };
  }

  return {
    base_exposure_type: "estimated_business_exposure",
    base_exposure_value: annualRevenue * 0.25,
    low_rate: 0.001,
    high_rate: 0.003,
  };
}

function buildExposurePath(cluster: any, impactHigh: number) {
  const riskType = String(cluster.risk_type || "").toLowerCase();

  if (
    riskType.includes("freight") ||
    riskType.includes("logistics") ||
    riskType.includes("shipping")
  ) {
    return [
      "Freight / logistics evidence cluster",
      "Transportation cost or capacity pressure",
      "Supplier lead time or landed cost exposure",
      "Customer service or margin pressure",
      `${formatMoneyForPath(impactHigh)} modeled exposure`,
    ];
  }

  if (
    riskType.includes("commodity") ||
    riskType.includes("tariff") ||
    riskType.includes("trade") ||
    riskType.includes("metals")
  ) {
    return [
      "Commodity / trade evidence cluster",
      "Input cost or tariff pressure",
      "Supplier landed cost pressure",
      "Customer pass-through or margin exposure",
      `${formatMoneyForPath(impactHigh)} modeled exposure`,
    ];
  }

  if (riskType.includes("demand") || riskType.includes("macro")) {
    return [
      "Demand evidence cluster",
      "Manufacturing / construction activity signal",
      "Customer order or sales planning sensitivity",
      "Revenue and inventory planning exposure",
      `${formatMoneyForPath(impactHigh)} modeled exposure`,
    ];
  }

  if (riskType.includes("competitor")) {
    return [
      "Competitor evidence cluster",
      "Pricing or service-level pressure",
      "Customer retention / quote-loss exposure",
      "Revenue at risk",
      `${formatMoneyForPath(impactHigh)} modeled exposure`,
    ];
  }

  return [
    "Evidence cluster",
    "Business driver identified",
    "Operating exposure pathway",
    "Executive decision required",
    `${formatMoneyForPath(impactHigh)} modeled exposure`,
  ];
}

function makePriorityScore(input: {
  probability: number;
  confidence: number;
  evidenceQuality: number;
  impactHigh: number;
}) {
  const impactScore = Math.min(25, Math.round(input.impactHigh / 1_000_000));

  return Math.max(
    35,
    Math.min(
      95,
      Math.round(
        input.probability * 0.35 +
          input.confidence * 0.25 +
          input.evidenceQuality * 0.25 +
          impactScore * 0.15
      )
    )
  );
}

function makeEvidenceItems(cluster: any, evidence: any[]) {
  const indexes = getCleanEvidenceIndexes(cluster, evidence);

  return indexes
    .map((idx) => evidence[idx - 1])
    .filter(Boolean)
    .map((item) => ({
      title: item.title,
      source: item.source_name,
      url: item.source_url,
      source_quality: item.source_quality || 50,
      source_tier: item.source_tier || "unknown",
      published_at: item.published_at,
      age_days: item.event_age_days ?? null,
      age_label:
        item.event_age_days === null || item.event_age_days === undefined
          ? "Unknown date"
          : `Age ${item.event_age_days} days`,

      strategic_score: Number(item.strategic_score || 0),
      confidence: Number(item.confidence || 0),
      impact_level: item.impact_level || null,
      impact_type: item.impact_type || null,
      why_it_matters: item.why_it_matters || null,

      evidence_score: Math.round(
        Math.max(
          Number(item.strategic_score || 0),
          Number(item.confidence || 0),
          Number(item.source_quality || 0)
        )
      ),
    }))
    .sort((a, b) => Number(b.evidence_score || 0) - Number(a.evidence_score || 0));
}

function makeSourceEventIds(cluster: any, evidence: any[]) {
  const indexes = getCleanEvidenceIndexes(cluster, evidence);

  return indexes.map((idx) => evidence[idx - 1]?.raw_event_id).filter(Boolean);
}

function buildEvidenceClusteringPrompt(input: {
  company: any;
  entities: any[];
  evidence: any[];
}) {
  const companyFacts = {
    company_name: input.company.name,
    industry: input.company.industry,
    revenue_range: input.company.revenue_range,
    suppliers: input.entities
      .filter((e) => e.entity_type === "supplier")
      .map((e) => e.entity_value),
    competitors: input.entities
      .filter((e) => e.entity_type === "competitor")
      .map((e) => e.entity_value),
    customer_segments: input.entities
      .filter((e) => e.entity_type === "customer_segment")
      .map((e) => e.entity_value),
    commodities: input.entities
      .filter((e) => e.entity_type === "commodity")
      .map((e) => e.entity_value),
  };

  return `
You are building an executive risk register for this company.

COMPANY:
${JSON.stringify(companyFacts, null, 2)}

TASK:
Group today's relevant evidence articles into 2 to 3 executive risk clusters.
Each cluster must use 3 to 8 directly relevant articles.
Do not include more than 8 evidence_indexes per cluster.

CRITICAL RULES:
- Do NOT use preset risk titles.
- Risk titles must be created from the actual article cluster.
- Each cluster must contain articles that truly belong together.
- Do NOT force copper, aluminum, freight, stock-market, and demand articles into the same generic demand risk.
- Do NOT create "Industrial Demand Sensitivity" unless the articles directly mention industrial demand, manufacturing activity, PMI, construction activity, orders, sales outlook, inventory destocking/restocking, or customer demand.
- Company profiles, stock movement articles, market-index articles, analyst rating articles, and market-cap articles are weak evidence unless they directly describe operating cost, demand, supply disruption, customer activity, prices, tariffs, freight, or lead times.
- If evidence is weak or indirect, either exclude it or create a lower-confidence cluster with a title that admits it is a watch item.
- Use article titles and source names directly in the explanations.
- Titles should be board-readable and specific.
- evidence_indexes must contain ONLY articles that directly support the exact risk_title.
- Do not include trade-adjacent articles unless they involve the same commodity, country, customer segment, or operating driver.
- For metals tariff risk, include steel/aluminum/copper/tariff/import/duty articles only. Exclude whisky, watches, broad stock-market, market-index, and unrelated trade articles.
- For freight risk, include freight/shipping/logistics/port/container/lead-time articles only.
- For demand risk, include manufacturing/construction/PMI/orders/customer-demand articles only.
- Each cluster should use 2 to 8 directly relevant articles. Never pad with weak articles.
- For steel/aluminum/copper tariff risks, evidence_indexes must include only articles that mention tariff/import/duty/proclamation/Section 232 AND steel/aluminum/copper.
- Exclude whisky, watches, apparel, broad market-index, stock-performance, and unrelated trade articles even if they mention tariffs.
- Exclude iron ore articles unless the article directly connects iron ore to steel tariffs, steel import costs, or Fastenal-relevant steel cost pressure.
- It is acceptable for a high-quality cluster to have only 2 direct evidence articles. Do not pad clusters with weak articles just to reach 3.

GOOD TITLE EXAMPLES:
- Steel, Aluminum, and Copper Tariff Cost Pressure
- Container Freight Rate Spike and Logistics Cost Pressure
- Copper and Aluminum Supply Tightness Watch
- Middle East Shipping Disruption Risk
- Manufacturing Demand Slowdown Watch

BAD TITLE EXAMPLES:
- Industrial Demand Sensitivity
- Risk Exposure
- Supply Chain Risk
- Market Risk
- Business Risk

EVIDENCE ARTICLES:
${JSON.stringify(input.evidence, null, 2)}
IMPORTANT OUTPUT LIMITS:
- Return at most 3 risk clusters.
- Each string field must be under 280 characters.
- what_happened must be 1-2 sentences only.
- why_now must be 1 sentence only.
- business_impact must be 1-2 sentences only.
- why_this_cluster_exists must be 1 sentence only.
- Do not quote full article titles inside long paragraphs; use short references.
- Keep JSON compact.
Return ONLY valid JSON:
{
  "risk_clusters": [
    {
      "risk_title": "specific title based on the article cluster",
      "risk_type": "commodity_cost | freight_logistics | supplier_disruption | customer_demand | competitor_pressure | tariff_trade | macro_market | other",
      "severity": "low | medium | high | critical",
      "probability": 0,
      "confidence": 0,
      "why_this_cluster_exists": "specific explanation of why these articles belong together",
      "what_happened": "specific explanation of what happened, naming article-backed developments",
      "why_now": "specific explanation of what is recent or changing",
      "business_impact": "specific explanation of how this could affect the company",
      "decision_required": "specific executive decision needed",
      "owner": "recommended owner title",
      "expected_benefit": "specific expected benefit of acting",
      "affected_suppliers": [],
      "affected_customers": [],
      "affected_products": [],
      "affected_commodities": [],
      "affected_facilities": [],
      "evidence_indexes": [1, 2, 3],
      "evidence_quality_score": 0
    }
  ]
}

SCORING:
- probability: modeled likelihood from article evidence, 0-100.
- confidence: confidence that the evidence actually supports this exact risk, 0-100.
- evidence_quality_score: source quality + relevance quality, 0-100.
- If evidence is indirect, confidence must be below 65.
- If evidence is mismatched, do not create a cluster.
`;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    if (!supabaseUrl || !serviceRoleKey) {
      return jsonResponse(
        {
          ok: false,
          error: "Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY.",
        },
        500
      );
    }

    const { createClient } = await import(
      "https://esm.sh/@supabase/supabase-js@2.45.4"
    );

    const supabase = createClient(supabaseUrl, serviceRoleKey);

    const body = await req.json().catch(() => ({}));
    const companyId = cleanText(body.companyId, 80);
    const maxEvidence = clampNumber(body.maxEvidence, 20, 120, 70);

    if (!companyId) {
      return jsonResponse({ ok: false, error: "Missing companyId." }, 400);
    }

    const { data: company, error: companyError } = await supabase
      .from("companies")
      .select("*")
      .eq("id", companyId)
      .single();

    if (companyError) throw companyError;

    const { data: entities, error: entityError } = await supabase
      .from("company_entities")
      .select("*")
      .eq("company_id", companyId);

    if (entityError) throw entityError;

    const { data: assessments, error: assessmentError } = await supabase
      .from("event_assessments")
      .select(
        `
        id,
        raw_event_id,
        relevant,
        impact_level,
        impact_type,
        why_it_matters,
        affected_areas,
        confidence,
        strategic_score,
        raw_event:raw_events (
          id,
          title,
          source_name,
          source_url,
          published_at,
          query_text,
          source_quality,
          source_tier,
          event_age_days
        )
      `
      )
      .eq("company_id", companyId)
      .eq("relevant", true)
      .order("strategic_score", { ascending: false })
      .limit(maxEvidence);

    if (assessmentError) throw assessmentError;

    const evidence = (assessments || [])
      .map((assessment: any, index: number) => {
        const raw = Array.isArray(assessment.raw_event)
          ? assessment.raw_event[0]
          : assessment.raw_event;

        return {
          index: index + 1,
          assessment_id: assessment.id,
          raw_event_id: assessment.raw_event_id,
          title: cleanText(raw?.title, 280),
          source_name: cleanText(raw?.source_name, 120),
          source_url: cleanText(raw?.source_url, 500),
          published_at: raw?.published_at,
          query_text: cleanText(raw?.query_text, 300),
          source_quality: raw?.source_quality || 50,
          source_tier: raw?.source_tier || "unknown",
          event_age_days: raw?.event_age_days ?? null,
          impact_level: assessment.impact_level,
          impact_type: assessment.impact_type,
          why_it_matters: cleanText(assessment.why_it_matters, 500),
          affected_areas: assessment.affected_areas || [],
          confidence: assessment.confidence || 0,
          strategic_score: assessment.strategic_score || 0,
        };
      })
      .filter((item: any) => item.title);

    if (evidence.length === 0) {
      return jsonResponse({
        ok: true,
        message: "No relevant evidence found.",
        inserted: 0,
      });
    }

    const clustered = await callGemini(
      buildEvidenceClusteringPrompt({
        company,
        entities: entities || [],
        evidence,
      })
    );

    const clusters = safeArray(clustered.risk_clusters).slice(0, 5);

    await supabase
      .from("risk_actions")
      .delete()
      .eq("company_id", companyId)
      .eq("source_type", "risk");

    await supabase.from("risk_register").delete().eq("company_id", companyId);

    const riskRows = clusters
      .map((cluster: any, index: number) => {
        const sourceEventIds = makeSourceEventIds(cluster, evidence);
        const evidenceItems = makeEvidenceItems(cluster, evidence);

        if (sourceEventIds.length === 0 || evidenceItems.length === 0) {
          return null;
        }

        const probability = clampNumber(cluster.probability, 1, 95, 55);
        const confidence = clampNumber(cluster.confidence, 1, 100, 55);
        const evidenceQuality = clampNumber(
          cluster.evidence_quality_score,
          1,
          100,
          55
        );

        const exposureBase = getBaseExposureForRisk({
          riskType: cluster.risk_type,
          company,
        });

        const eMult = evidenceMultiplier(evidenceItems.length);
        const qMult = qualityMultiplier(evidenceQuality);

        const impactLow =
          exposureBase.base_exposure_value *
          exposureBase.low_rate *
          eMult *
          qMult;

        const impactHigh =
          exposureBase.base_exposure_value *
          exposureBase.high_rate *
          eMult *
          qMult;

        const priorityScore = makePriorityScore({
          probability,
          confidence,
          evidenceQuality,
          impactHigh,
        });

        return {
          company_id: companyId,
          risk_title: cleanText(cluster.risk_title, 180),
          risk_type: cleanText(cluster.risk_type, 80) || "evidence_cluster",
          probability: Math.round(probability),
          impact_low: Math.round(impactLow),
          impact_high: Math.round(impactHigh),
          confidence: Math.round(confidence),
          severity: cleanText(cluster.severity, 40) || "medium",
          owner: cleanText(cluster.owner, 120) || "Executive Owner",
          action_required:
            cleanText(cluster.decision_required, 1000) ||
            "Review the evidence cluster and decide whether mitigation is needed.",
          due_days: index === 0 ? 7 : 14,
          status: "open",

          affected_suppliers: safeArray(cluster.affected_suppliers),
          affected_customers: safeArray(cluster.affected_customers),
          affected_products: safeArray(cluster.affected_products),
          affected_commodities: safeArray(cluster.affected_commodities),
          affected_facilities: safeArray(cluster.affected_facilities),

          source_event_ids: sourceEventIds,
          supporting_event_count: sourceEventIds.length,

          executive_summary:
            cleanText(cluster.what_happened, 900) ||
            cleanText(cluster.why_this_cluster_exists, 900),
          business_impact: cleanText(cluster.business_impact, 1500),

          priority_score: priorityScore,
          risk_rank: index + 1,

          what_happened: cleanText(cluster.what_happened, 2000),
          why_now: cleanText(cluster.why_now, 2000),
          risk_interaction: cleanText(cluster.business_impact, 2000),
          evidence_summary: cleanText(cluster.why_this_cluster_exists, 1000),
          explanation_confidence: Math.round(confidence),

          evidence_items: evidenceItems,
          evidence_quality_score: Math.round(evidenceQuality),
          evidence_titles: evidenceItems.map((item: any) => item.title),
          evidence_sources: evidenceItems.map((item: any) => item.source),
          evidence_urls: evidenceItems.map((item: any) => item.url),

          decision_required: cleanText(cluster.decision_required, 1000),
          expected_benefit: cleanText(cluster.expected_benefit, 1000),

          methodology: {
            generator_version: "dynamic-evidence-cluster-risk-v1",
            aggregation_method:
              "Gemini clustered same-day scored evidence first; risk title generated from evidence cluster.",
            base_exposure_type: exposureBase.base_exposure_type,
            base_exposure_value: exposureBase.base_exposure_value,
            risk_rate_low: exposureBase.low_rate,
            risk_rate_high: exposureBase.high_rate,
            supporting_signal_count: sourceEventIds.length,
            average_source_quality: Math.round(evidenceQuality),
            evidence_multiplier: Number(eMult.toFixed(3)),
            quality_multiplier: Number(qMult.toFixed(3)),
            final_low: Math.round(impactLow),
            final_high: Math.round(impactHigh),
            cluster_reason: cleanText(cluster.why_this_cluster_exists, 1000),
          },

          exposure_path: buildExposurePath(cluster, impactHigh),
        };
      })
      .filter(Boolean);

    if (riskRows.length === 0) {
      return jsonResponse({
        ok: true,
        inserted: 0,
        message: "Gemini produced no valid risk clusters with evidence.",
        clusters,
      });
    }

    const { data: insertedRisks, error: insertError } = await supabase
      .from("risk_register")
      .insert(riskRows)
      .select(
        "id, risk_title, owner, action_required, expected_benefit, due_days"
      );

    if (insertError) throw insertError;

    const actionRows = (insertedRisks || []).map((risk: any) => {
      const deadline = new Date();
      deadline.setUTCDate(deadline.getUTCDate() + Number(risk.due_days || 14));

      return {
        company_id: companyId,
        risk_id: risk.id,
        title: risk.action_required,
        owner: risk.owner,
        deadline: deadline.toISOString().slice(0, 10),
        expected_benefit: risk.expected_benefit,
        status: "open",
        source_type: "risk",
      };
    });

    if (actionRows.length > 0) {
      const { error: actionError } = await supabase
        .from("risk_actions")
        .insert(actionRows);

      if (actionError) throw actionError;
    }

    return jsonResponse({
      ok: true,
      generator_version: "dynamic-evidence-cluster-risk-v1",
      evidence_loaded: evidence.length,
      clusters_returned: clusters.length,
      inserted: riskRows.length,
      risks: riskRows.map((row: any) => ({
        risk_title: row.risk_title,
        source_event_count: row.source_event_ids.length,
        evidence_titles: row.evidence_titles,
      })),
    });
  } catch (error) {
    return jsonResponse(
      {
        ok: false,
        error: error instanceof Error ? error.message : String(error),
        stack: error instanceof Error ? error.stack : null,
      },
      500
    );
  }
});